from Biblioteca import *
def generarMsjMenu():
    msj= "\nBIENVENIDOS AL TALLER DE CICLOS Y FUNCIONES"
    msj+="\n\nSeleccione la opcion que desar probar:\n "
    msj+="\n1.Contar vocales de un texto."
    msj+="\n2.Contar vocales de un texto de manera detallada."
    msj+="\n3.Suprimir vocales de un texto."
    msj+="\n4.Mostrar nombres que iniciaron en vocal, cuantos finalizaron en consonantes y de los nombres ingresados cuantos inician en minuscula"
    msj+="\n5.Poicion del caracter dentro de la cadena."
    msj+="\n6.Descubir mensaje encriptado."
    msj+="\n0.Para terminar. "
    msj+="\nPor favor escriba el número que desea seleeccionar: "
    return msj

#procedimiento que genera el menu de opciones en codigo, una vez el usuario ya seleccionó la opción
def generarMenu():
    opcion=-1
    ejecutar=True
    while(ejecutar):
        msjMenu = generarMsjMenu()
        opcion = leerInt(msjMenu)
        if(opcion==1):
            desarrollarPunto1()
        elif(opcion==2):
            desarrollarPunto2()
        elif(opcion==3):
            desarrollarPunto3()
        elif(opcion==4):
            desarrollarPunto4()
        elif(opcion==5):
            desarrollarPunto5()
        elif(opcion==6):
            desarrollarPunto6()
        elif(opcion==0):
            ejecutar=False
        else:
            imprimir("opcion incorrecta")
           
        imprimir("Muchas gracias por su visita, lo esperamos pronto\n\n")

#principal
def main():
        generarMenu()
main()

