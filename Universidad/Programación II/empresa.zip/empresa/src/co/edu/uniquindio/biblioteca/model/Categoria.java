package co.edu.uniquindio.biblioteca.model;

public enum Categoria {

	ADMINISTRADOR,GERENTE,SUBGERENTE
}
