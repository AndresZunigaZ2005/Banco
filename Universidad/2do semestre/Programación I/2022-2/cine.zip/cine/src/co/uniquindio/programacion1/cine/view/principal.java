package co.uniquindio.programacion1.cine.view;

import co.uniquindio.programacion1.cine.aplicación.dostosClientes;

public class principal {

	public static void main(String[] args) {
		dostosClientes misClientes =new dostosClientes();
		misClientes.setVisible(true);

	}

}
