package co.uniquindio.programacion1.cine.aplicación;

public class informacionCliente {

}
