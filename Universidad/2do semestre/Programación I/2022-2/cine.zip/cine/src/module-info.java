/**
 * 
 */
/**
 * @author SOFIA
 *
 */
module cine {
	requires java.desktop;
}